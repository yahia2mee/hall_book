<?php require_once('Connections/localhost.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>صالات الافراح</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script src="includes/jquery/jquery-1.10.2.js"></script>
<script src="includes/jquery/jquery-ui-custom.js"></script>
<script src="includes/jquery/maskedinput.js"></script>
<script src="includes/bootstrap/js/bootstrap.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<style>
#map_wrapper {
    height: 400px;
}

#map_canvas {
    width: 100%;
    height: 100%;
}
</style>
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: #555555;} /* Black */
</style>
<style>

th, td {
    padding: 15px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color: #fff;
}
table#t01 th {
    background-color: black;
    color: white;
}
</style>
<style>


h1 {
    text-align: center;
    text-transform: uppercase;
    color: #4CAF50;
}



</style>
</head>
<body>
	<div class="main_container" >
        <a href="index.php"><img src="images/logo.png" align="left" /></a>
            <div id="headr_img">
                <span id="main_nav"> <b>
                	   	<a href="index.php">الرئيسية</a> |  
						<a href="catalogue.php">العرض</a> |  
                        <a href="reserve.php">الحجز</a> |  
                        <a href="contact.php">اتصل بنا</a>
						</b>
	            </span>
            </div>
			<center>
			<table class="hoverTable" id="eee" data-responsive="table" style="text-align: left;" dir="rtl">
	<thead>
		<tr>
			<th width="25%"><form method = "POST" action="dates1.php" enctype = "multipart/form-data" dir="rtl">
				<button type="submit" name="save" class="button"> صالة الوداد</button>
				</form> </th>
				<th width="25%"><form method = "POST" action="dates2.php" enctype = "multipart/form-data" dir="rtl">
				<button type="submit"  name="save" class="button button2"> صالة ماجستك</button>
				</form> </th>
				<th width="25%"><form method = "POST" action="dates3.php" enctype = "multipart/form-data" dir="rtl">
				<button type="submit"  name="save" class="button button3"><span class = "glyphicon glyphicon-save"></span>صالة فيوتشر</button>
				</form></th>
				<th width="27"><form method = "POST" action="dates4.php" enctype = "multipart/form-data" dir="rtl">
				<button type="submit"  name="save" class="button button4"><span class = "glyphicon glyphicon-save"></span>القصر الملكي </button>
				</form></th>
		</tr>
	</thead>
	<tbody>

</table>

<h1> التاريخ أدناه محجوز
</h1>
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
				   </center>
				
				
  <CENTER>

  		<table class="hoverTable" id="t01" data-responsive="table" style="text-align: left;" dir="rtl">
	<thead>
		<tr>
			<th width="100%">التاريخ المحجوز </th>
				
		</tr>
	</thead>
	<tbody>
			<?php
			include('connect.php');
				$result = $db->prepare("SELECT * FROM reservations");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
			?>
			<td><?php echo $row['rsrv_start']; ?></td>
		
		

			</tr>
			
	<?php
				}
			?>
		
	</tbody>
</table>
</CENTER>
    <div id="map_wrapper">
    <div id="map_canvas" class="mapping"></div>
</div>
<br />
    
   </div>
         <div id="footer_container">
         	2018
         </div>
	</div>

</body>
</html>