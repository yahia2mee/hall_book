<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>صالات الافراح</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
   <link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
    <script type="text/javascript" src="engine1/jquery.js"></script>
</head>
<body>
	<div class="main_container" >
        <a href="#"><img src="images/logo.png" align="left" /></a>
            <div id="headr_img">
                <span id="main_nav"> <b>
                	   	<a href="index.php">الرئيسية</a> |  
						<a href="catalogue.php">العرض</a> |  
                        <a href="reserve.php">الحجز</a> |  
                        <a href="#">اتصل بنا</a></b>
                </span>
            </div>
   <div id="content_container" dir="rtl">
   <h2>صالة ماجستك</h2>
        <div id="wowslider-container1">
            <div class="ws_images">
                <ul>
                    <li><img src="data1/images/pic2.jpg" alt="Deluxe" title="صالة ماجستك"<id="wows1_0"/></li>
                    <li><img src="data1/images/102_4646.jpg" alt="Deluxe" title="صالة ماجستك" <id="wows1_1"/></li>
                </ul>
            </div>
        <div class="ws_bullets">
            <div>
                <a href="#" title="Deluxe"><img src="data1/tooltips/pic2.jpg" alt="Deluxe"/>1</a>
                <a href="#" title="Deluxe"><img src="data1/tooltips/102_4646.jpg" alt="Deluxe"/>2</a>
            </div>
        </div>
            <div class="ws_shadow"></div>
	   </div>
	       <script type="text/javascript" src="engine1/wowslider.js"></script>
	       <script type="text/javascript" src="engine1/script.js"></script>
	    <br />
        <div id="wowslider-anchor">
            <div class="a1">
                <span><a class="button fright" href="reserve.php" >احجز الآن</a></span>
            </div>
            <div class="a2">
                <span><a class="button fright" href="pricing.php">الأسعار</a></span>
            <p></p>
	  <p></p>
	  <br />
	  <br />
	  <br /><br /><br />
	<div id="map-canvas"></div><br />
        </div>
	
    </div>
	 
      </div>
	 
	  <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	  <script>
function initialize() {
  var myLatlng = new google.maps.LatLng(15.5594692,32.5591602);
  var mapOptions = {
    zoom: 17,
    center: myLatlng
  }
  var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

  var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,
      title: 'مرحبا بكم'
  });
}

google.maps.event.addDomListener(window, 'load', initialize);
    </script>
         <div id="footer_container">
         	2018
      </div>
</div>
</body>
</html>