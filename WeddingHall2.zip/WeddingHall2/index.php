<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>صالات الافراح</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
</head>
<body>
	<div class="main_container" >
        <a href="#"><img src="images/logo.png" align="left" /></a>
            <div id="headr_img">
                <span id="main_nav"> <b> 
                	   	<a href="#">الرئيسية</a> |  
						<a href="catalogue.php">العرض</a> |  
                        <a href="reserve.php">الحجز</a> |  
                        <a href="contact.php">اتصل بنا</a> |
						  <a href="dates.php">الحجوزات</a>
						</b>
                </span>
            </div>
   <div id="content_container" dir="rtl">
<div id="welcome">
                	<p id="home_header">
						خدمات ممتازة وأسعار مقبولة....
                    </p>
                    <p>نحن نقدم لك أرقى الخدمات في ليلة العمر أو أي مناسبات أخرى </p>
                    <p>					نمتلك مجموعة صالات يمكنك الاختيار بينها..
 كل واحدة تنافس الأخرى
 بمميزات رااائعة وخدمات ممتازة ..
 يمكنك استعراض الصالات
 وعرض الصور والموقع الفعلي للصالةالآن....
 كل ما عليك هو الضغط على عرض الصالات في الأسفل</p>
<p id="home_header">خدمات تقدم مجانا</p>
    <ul>
        <li><i class="icon-li icon-ok"></i> انترنت مجاني</li>
        <li>وصلات الشاشات والكهرباء</li>
        <li>تكييف عالي </li>
        <li>صالات نظيفة بنسبة 100%</li>
    </ul>
       	   </div>
           <span id="img_shadow"><img src="images/1011_n.png"/></span>
                      <div class="call_to_action" id="grn"><a href="reserve.php">إحجز الآن</a></div>
                      <div class="call_to_action" id="orn"><a href="catalogue.php">عرض الصالات</a></div>
      </div>
         <div id="footer_container">
         	2018
      </div>
</div>
</body>
</html>