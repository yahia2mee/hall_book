<?php require_once('Connections/localhost.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
	$mm = $_POST['rsrv_start'];
	$tt = $_POST['rsrv_room'];
		$query = mysql_query("select * from reservations where rsrv_start = '$mm' and rsrv_room = '$tt' ")or die(mysql_error());
		$count = mysql_num_rows($query);
		
	/* 	echo $count; */
		if ($count  > 0){ ?>
		
		<script>
		alert('عذراً هذا اليوم محجوز مسبقاً الرجاء مراجعة تواريخ الحجز أولاً');
		window.location.href = "dates.php";
		</script>
		
		<?php
		
		}else{
  $insertSQL = sprintf("INSERT INTO reservations (rsrv_id, rsrv_timestamp, rsrv_first_name, rsrv_last_name, rsrv_email, rsrv_contact, rsrv_room, rsrv_bed, rsrv_pillow, rsrv_towel, rsrv_kit, rsrv_start, rsrv_end, rsrv_guest, rsrv_notes) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['rsrv_id'], "int"),
                       GetSQLValueString($_POST['rsrv_timestamp'], "date"),
                       GetSQLValueString($_POST['rsrv_first_name'], "text"),
                       GetSQLValueString($_POST['rsrv_last_name'], "text"),
                       GetSQLValueString($_POST['rsrv_email'], "text"),
                       GetSQLValueString($_POST['rsrv_contact'], "int"),
                       GetSQLValueString($_POST['rsrv_room'], "text"),
                       GetSQLValueString($_POST['rsrv_bed'], "int"),
                       GetSQLValueString($_POST['rsrv_pillow'], "int"),
                       GetSQLValueString($_POST['rsrv_towel'], "int"),
                       GetSQLValueString($_POST['rsrv_kit'], "int"),
                       GetSQLValueString($_POST['rsrv_start'], "date"),
                       GetSQLValueString($_POST['rsrv_end'], "date"),
                       GetSQLValueString($_POST['rsrv_guest'], "int"),
                       GetSQLValueString($_POST['rsrv_notes'], "text"));

  mysql_select_db($database_localhost, $localhost);
  $Result1 = mysql_query($insertSQL, $localhost) or die(mysql_error());

  $insertGoTo = "reservation/thank-you.php?rsrv_first_name=$_POST[rsrv_first_name]";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>صالات الافراح</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" media="all" href="includes/jquery/jquery-ui-custom.css" />
<script src="includes/jquery/jquery-1.10.2.js"></script>
<script src="includes/jquery/jquery-ui-custom.js"></script>
<script src="includes/jquery/maskedinput.js"></script>
<script src="includes/bootstrap/js/bootstrap.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script>
  jQuery(document).ready(function($) {var dateToday = new Date();
var dates = $("#dateStart, #dateEnd").datepicker({
    defaultDate: "+1w",
	dateFormat: 'yy-mm-dd',
    changeMonth: true,
    numberOfMonths: 1,
    minDate: dateToday,
    onSelect: function(selectedDate) {
        var option = this.id == "dateStart" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker.settings.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
   	 }
	});
});
  </script>
  <script>
  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		<?php 
$PHPtext = "هذا الحقل يقبل أرقام فقط";
?>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); 
        return false;
    }
    return true;
}
</script>
        <script>
            function istext(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return true;
    }
			<?php 
$PHPtext = "هذا الحقل يقبل حروف فقط";
?>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); 
    return false;
}
</script>
<script type="text/javascript">
	jQuery(function($){
   $("#rsrv_contact").mask("99999999999");
	});
	</script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="main_container" >
        <a href="index.php"><img src="images/logo.png" align="left" /></a>
            <div id="headr_img">
                <span id="main_nav"> <b>
                	   	<a href="index.php">الرئيسية</a> |  
						<a href="catalogue.php">العرض</a> |  
                        <a href="reserve.php">الحجز</a> |  
                        <a href="contact.php">اتصل بنا</a> </b>
	            </span>
            </div>
   <div id="content_container" dir="rtl">
  
            <div id="content_left">
<h2 id="home_header">استمارة الحجز</h2>
<form action="<?php echo $editFormAction; ?>" method="POST" name="form1" id="rsrv_form">
                <label>الاسم الاول</label><br />
<span id="sprytextfield1">
                <input type="text" name="rsrv_first_name" value="" size="30" placeholder="Type here" id="fname" onKeyPress="return istext(event)"/>
      <span class="textfieldRequiredMsg">هذا الحقل ضروري</span></span><br/>
                <label>الاسم الثاني</label><br />
<span id="sprytextfield2">
                <input type="text" name="rsrv_last_name" value="" size="30" placeholder="Type here" onKeyPress="return istext(event)"/>
                <span class="textfieldRequiredMsg">هذا الحقل ضروري</span></span><br /><label>البريد الالكتروني</label><br />
<input type="text" name="rsrv_email" value="" size="30" placeholder="Type here" /><br />
                <label>الهاتف</label><br />
                <span id="sprytextfield3">
                <input type="text" name="rsrv_contact" value="" size="30"  placeholder="Type here" onKeyPress="return isNumber(event)" />
<span class="textfieldRequiredMsg">هذا الحقل ضروري</span></span><br />
                <label>عدد الضيوف المتوقع</label></br>
                  <select name="rsrv_guest" size="1" id="select" placeholder="Select">
                    <option value="300">300</option>
                    <option value="500">500</option>
                    <option value="700">700</option>
                    <option value="900">900</option>
                    <option value="1000">1000</option>
                    <option value="1200">1200</option>
                    <option value="1300">1300</option>
                    <option value="1400">1400</option>
                    <option value="1500">1500</option>
                   
                  <values>
                  </select>
                  <br /><br />
                  <label><b>الصالة</b></label>
                      <fieldset><label>
                        <input name="rsrv_room" type="radio" id="rsrv_room_1" value="الوداد 35000" checked="checked" />
                       صالة الوداد - السعة 1200 شخص - السعر 35000</label><br/>
                      <label>
                        <input type="radio" name="rsrv_room" value=" ماجستك 35000" id="rsrv_room_2" />
                      صالة ماجستك - السعة 1200 شخص - السعر 35000</label><br/>
						<label>
                        <input type="radio" name="rsrv_room" value=" فيوتشر 40000" id="rsrv_room_2" />
                        صالة فيوتشر - السعة 1500 شخص - السعر 40000</label><br/>
                      <label>
                        <input type="radio" name="rsrv_room" value="القصر الملكي 37000" id="rsrv_room_3" />
                        القصر الملكي - السعة 1500 شخص - السعر 37000</label><br/>
                        </fieldset>
                      <label><b>الاضافات</b></label>
                      <fieldset>
                        <label>ساعة اضافية - السعر 3000
                          <select name="rsrv_bed" id="rsrv_bed">
                    <option value="0">لا</option>
                    <option value="3000">نعم</option>
                    
                    <values>
                          </select>
                        </label><br/>
                        <label>الفنان - السعر 30 - 45
                 
						  
                  <select name="category" class="form-control" width="18">
  <option value="0"> ...اضغط للاختيار...</option>
    <option value="no" rel="no">لا</option>
	<option value="yes" rel="yes">نعم</option>

</select>
						  <select name="rsrv_towel" id="rsrv_towel" class="cascade" width="18">
						  <option value="45000" class="yes">من فضلك اختر هنا</option>
    <option value="طه سليمان 45000" class="yes">طه سليمان 45000</option>
	<option value="شكر الله عز الدين 35000" class="yes">شكر الله عز الدين 35000</option>
	<option value="حمادة بشير 35000" class="yes">حمادة بشير 35000</option>
	<option value="وليد جوبا 35000" class="yes">وليد جوبا 35000</option>
	<option value="محمد الريان 35000" class="yes">محمد الريان 35000</option>
    <option value="مصطفى البربري 30000" class="yes">مصطفى البربري 30000</option>
    <option value="مهاب عثمان 30000" class="yes">مهاب عثمان 30000</option>
	<option value="عبد الخارق 30000" class="yes">عبد الخارق 30000</option>

<option value="1" class="no">لا أرغب بفنان</option>
	<option value="2" class="no">يوجد لدي فنان مسبقاً</option>
	
</select>
						  
                        </label><br/>
                        <label>التصوير
                          <select name="rsrv_pillow" id="rsrv_pillow">
                <option value="0">لا</option>
                    <option value="10000">نعم</option>
                    <values>
                          </select>
                        </label><br/>
                     <label>العشاء
                          <select name="rsrv_kit" id="rsrv_kit" class="form-control" width="18">
                  <option value="0" rel="nn">لا</option>
                    <option value="40000" rel="yy">نعم</option>
                   
                          </select>
						  <select name="rsrv_kit2" id="rsrv_kit2" class="cascade" width="18">
						  <option value="45000" class="yes">من فضلك اختر هنا</option>
    <option value="صغير 25000" class="yy">صغير 25000</option>
	<option value="متوسط 35000" class="yy">متوسط 35000</option>
	<option value="كبير 45000" class="yy">كبير 45000</option>
	
	</select>
                        </label><br/>
                        
      </fieldset>
<label>تاريخ الحجز</label><br />
<fieldset>
				<label>تاريخ الحجز</label>
<span id="sprytextfield4">
				<input type="text" name="rsrv_start" value="" size="15" id="dateStart" placeholder="Pick a Date"  />
	  <span class="textfieldRequiredMsg">من فضلك اختر التاريخ</span></span><br />
                <label></label>
                <span id="sprytextfield5">
				             <label>طريقة الدفع
                 
						  
                  <select name="category2" class="form-control" width="18">
  <option value="0"> ...اضغط للاختيار...</option>
    <option value="m" rel="m">دفع مباشر</option>
	<option value="bank" rel="bank">عن طريق البنك</option>

</select>
						  <select name="rsrv_end" id="rsrv_towel" class="cascade" width="18">
						  <option value="0000" class="bank">من فضلك اختر هنا</option>
    <option value="بنك الخرطوم - الحساب - 234566" class="bank">بنك الخرطوم - الحساب - 234566</option>
	<option value="بنك أمدرمان الوطني - الحساب - 3444543" class="bank">بنك أمدرمان الوطني - الحساب - 3444543</option>
	<option value="بنك فيصل - الحساب - 78687" class="bank">بنك فيصل - الحساب - 78687</option>


<option value="دفع مباشر" class="m">دفع مباشر</option>
	
</select>
              <!--  <input type="hidden" name="rsrv_end" value="2027-01-21" size="15" id="dateEnd" placeholder="Pick a Date" />         
      <span class="textfieldRequiredMsg">من فضلك اختر التاريح</span></span><br/>
     <!-- <div class="check_avail"><a href="">Check Availability</a></div> --></fieldset>
                <label>ملاحظات أخرى</label><br />
<textarea name="rsrv_notes" cols="40" rows="5"></textarea>
                <input type="submit" value="تأكيد الحجز" /> <input name="Reset" type="reset" value="الغاء" />
      <input type="hidden" name="rsrv_id" value="" />
                <input type="hidden" name="rsrv_timestamp" />
                <input type="hidden" name="MM_insert" value="form1" />
</form>
     </div>
     <div id="content_right">
     </div>
   </div>
         <div id="footer_container">
         	2018
         </div>
	</div>
	<style>


div.absolute {
    position: absolute;
 
    width: 400px;
    height: 500px;
    border: 3px solid #73AD21;
}
</style>
</head>
<body>
<script>
    function calcSum() {
        let rsrv_first_name = document.getElementsByName("rsrv_first_name")[0].value;
        let lable1 = Number(rsrv_first_name);
        document.getElementsByName("sum")[0].value = sum;
    }
</script>
 
  <div class="absolute" style="position: absolute; left: 257px; top: 459px;">

  <center>
  <h3>مجموعة أوسو للأفراح</h3>
    <p><h3>فاتورة الحجز</h3></p>
	
	 <p><h3><label name="sum" > </h3></p>
	 <input type="button" value="Sum" onclick="calcSum()">
  </center> 
  </div>
</div>
	<style>

		.cascade {
    display: none;

-webkit-appearance: button;
   -webkit-border-radius: 2px;
   -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
   -webkit-padding-end: 20px;
   -webkit-padding-start: 2px;
   -webkit-user-select: none;
   background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 40%, #E5E5E5);
   background-position: 97% center;
   background-repeat: no-repeat;
   border: 1px solid #AAA;
   color: #555;
   font-size: inherit;
   margin: 2px;
   overflow: hidden;
   padding: 5px 10px;
   text-overflow: ellipsis;
   white-space: nowrap;
   width: 150px;

}



		</style>
		<script>
		$(document).ready(function(){
    var $cat = $('select[name=category]'),
        $items = $('select[name=rsrv_towel]');

    $cat.change(function(){
        var $this = $(this).find(':selected'),
            rel = $this.attr('rel'),
            $set = $items.find('option.' + rel);

        if ($set.size() < 0) {
            $items.hide();
            return;
        }

        $items.show().find('option').hide();

        $set.show().first().prop('selected', true);
    });
});
		</script>
				<script>
		$(document).ready(function(){
    var $cat = $('select[name=rsrv_kit]'),
        $items = $('select[name=rsrv_kit2]');

    $cat.change(function(){
        var $this = $(this).find(':selected'),
            rel = $this.attr('rel'),
            $set = $items.find('option.' + rel);

        if ($set.size() < 0) {
            $items.hide();
            return;
        }

        $items.show().find('option').hide();

        $set.show().first().prop('selected', true);
    });
});
		</script>
		<script>
		$(document).ready(function(){
    var $cat = $('select[name=category2]'),
        $items = $('select[name=rsrv_end]');

    $cat.change(function(){
        var $this = $(this).find(':selected'),
            rel = $this.attr('rel'),
            $set = $items.find('option.' + rel);

        if ($set.size() < 0) {
            $items.hide();
            return;
        }

        $items.show().find('option').hide();

        $set.show().first().prop('selected', true);
    });
});
		</script>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");

</script>
</body>
</html>