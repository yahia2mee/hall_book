﻿-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2018 at 08:55 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(7, 'ss', 'ss'),
(8, 'ØºØ´Ø§Ù‡Ø´', 'Ù‚Ù‚Ù‚Ù‚Ù‚Ù‚');

-- --------------------------------------------------------

--
-- Table structure for table `club`
--

CREATE TABLE `club` (
  `club_id` int(11) NOT NULL,
  `club_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `club`
--

INSERT INTO `club` (`club_id`, `club_name`) VALUES
(1, 'ÙƒØ±Ø© Ø§Ù„Ù‚Ø¯Ù…'),
(3, 'ØºÙ†Ø§Ø¡'),
(4, 'Ø±ÙŠØ§Ø¶Ø©');

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `group_id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `mem_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`group_id`, `club_id`, `mem_id`) VALUES
(4, 1, 1),
(6, 4, 14);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `mem_id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `pod` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `ms` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `Note` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mem_id`, `firstname`, `dob`, `pod`, `address`, `ms`, `phone`, `email`, `Note`) VALUES
(13, 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', '2018-08-23', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨', 'Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨Ø¨'),
(14, 'Ø´Ø³ÙŠØ´ÙŠ', '2018-08-22', 'Ø´ÙŠØ´Ø³ÙŠ', 'Ø´Ø³ÙŠØ´Ø³ÙŠ', 'Ø§Ù†Ø«Ù‰', '5454545', 'admin@admin.com', 'Ø´ÙŠØ´ÙŠØ´Ø³ÙŠ'),
(15, 'Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³', '2018-08-03', 'Ø³Ø³Ø³Ø³Ø³Ø³', '  Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³', 'Ø§Ù†Ø«Ù‰', '1111111111111', 'YAHIA2MEE@YAHOO.com', '  Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³Ø³\" \" ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `club`
--
ALTER TABLE `club`
  ADD PRIMARY KEY (`club_id`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`mem_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `club`
--
ALTER TABLE `club`
  MODIFY `club_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `mem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
