<!DOCTYPE HTML>
<?php
	require_once 'session.php';
	require_once 'account_name.php';
?>
<html lang = "eng">
	<head>
		<meta charset =  "UTF-8">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<title>صالات الافراح</title>
	</head>
<body class = "alert-warning">
	<nav class  = "navbar navbar-inverse">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">صالات الافراح</a>
			</div>
				<ul class="nav navbar-nav navbar-right">
					<li><a><span class = "glyphicon glyphicon-user"></span> <?php echo $acc_name?></a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">اعداد <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="logout.php">خروج</a></li>
						</ul>
					</li>
				</ul>
		</div>
	</nav>
	<div class = "container-fluid">
		<ul class="nav nav-pills">
			<li><a href="home.php">الرئيسية</a></li>
			<li><a href="account.php">الحساب</a></li>
			<li class="active"><a href="member.php">الحجوزات</a></li>
			<li><a href="sms.php">الرسائل</a></li>
		</ul>
		<br />
		<div class = "col-md-12 well">
			<button type = "button" class = "btn btn-success" ><span class = "glyphicon glyphicon-plus"></span>طباعة</button>
			<br/>
			<br/>
			<div class = "alert alert-info">
				<table id = "table" class = "table-bordered" dir="rtl">
					<thead>
						<tr>
						 <td>م</td>
     <td>تاريخ الطلب</td>
     <td>الاسم الاول</td>
     <td>الاسم الاخير</td>
     <td>الهاتف</td>
     <td>تاريخ الحجز</td>
   
     <td>الصالة</td>
     <td>ساعة اضافية</td>
     <td>جرتق</td>
     <td>عشاء</td>
     <td>فنان</td>
     <td>ملاحظة</td>
     <td>اجراء</td>
						</tr>
					</thead>
					<tbody>
						<?php
							$query = $conn->query("SELECT * FROM `reservations`") or die(mysqli_error());
							while($f_query = $query->fetch_array()){
						?>
						<tr>
							<td><?php echo $f_query['rsrv_id']?></td>
							<td><?php echo $f_query['rsrv_timestamp']?></td>
							<td><?php echo $f_query['rsrv_first_name']?></td>
							<td><?php echo $f_query['rsrv_last_name']?></td>
							<td><?php echo $f_query['rsrv_contact']?></td>
							<td><?php echo $f_query['rsrv_start']?></td>
							<td><?php echo $f_query['rsrv_room']?></td>
							<td><?php echo $f_query['rsrv_bed']?></td>
							<td><?php echo $f_query['rsrv_towel']?></td>
							<td><?php echo $f_query['rsrv_pillow']?></td>
							<td><?php echo $f_query['rsrv_kit']?></td>
							<td><?php echo $f_query['rsrv_notes']?></td>
							
							<td><center><a  href = "delete_member.php?rsrv_id=<?php echo $f_query['rsrv_id']?>" class = "btn btn-danger"><span class = "glyphicon glyphicon-trash"></span> حذف</a></center></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	<footer class = "navbar navbar-fixed-bottom navbar-inverse">
		<label class = "pull-right"><?php echo date('Y', strtotime('+8 HOURS'))?> </label>
	</footer>
</body>	
<script src = "js/jquery-3.1.1.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "js/script.js"></script>
<script src = "js/jquery.dataTables.min.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	})
</script>
</html>