<?php
	require_once 'conn.php';
	$firstname = $_POST['firstname'];
	$dob = $_POST['dob'];
		$pod = $_POST['pod'];
			$address = $_POST['address'];
				$ms = $_POST['ms'];
					$phone = $_POST['phone'];
						$email = $_POST['email'];
							$Note = $_POST['Note'];
								
	$conn->query("INSERT INTO `member` VALUES('', '$firstname', '$dob', '$pod', '$address', '$ms', '$phone', '$email', '$Note')") or die(mysqli_error());
