<!DOCTYPE HTML>
<?php
	require_once 'session.php';
	require_once 'account_name.php';
?>
<html lang = "eng">
	<head>
		<meta charset =  "UTF-8">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<title>مركز شباب امدرمان</title>
	</head>
<body class = "alert-warning">
	<nav class  = "navbar navbar-inverse">
		<div class = "container-fluid">
			<div class = "navbar-header" >
				<a class = "navbar-brand">مركز شباب امدرمان</a>
			</div>
				<ul class="nav navbar-nav navbar-right">
					<li><a><span class = "glyphicon glyphicon-user"></span> <?php echo $acc_name?></a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">اعداد <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="logout.php">خروج</a></li>
						</ul>
					</li>
				</ul>
		</div>
	</nav>
	<div class = "container-fluid">
		<ul class="nav nav-pills">
			<li><a href="home.php">الرئيسية</a></li>
			<li><a href="account.php">الحساب</a></li>
			<li class="active"><a href="member.php">الاعضاء</a></li>
			<li><a href="club.php">النشاطات</a></li>
		</ul>
		<br />
		<div class = "col-md-12 well">
			<a class = "btn btn-success" href = "member.php"><span class = "glyphicon glyphicon-hand-right"></span> رجوع</a>
			<br/>
			<br/>
			<div class = "alert alert-warning" dir="rtl">تعديل بيانات عضو</div>
			<div class = "row">	
				<div class = "col-md-2 ">
				</div>
				<div class = "col-md-2">
				</div>
				<div class = "col-md-4">
					<?php
						$acc_query = $conn->query("SELECT * FROM `member` WHERE mem_id = '$_REQUEST[mem_id]'") or die(mysqli_error());
						$acc_fetch = $acc_query->fetch_array();
					?>
					<form method = "POST" dir="rtl">
						<div class = "form-group">
							<label>الاسم</label>
							<input  id = "firstname" type = "text" value = "<?php echo $acc_fetch['firstname']?>" class = "form-control" />
							<input  id = "mem_id" type = "hidden" value = "<?php echo $acc_fetch['mem_id']?>" class = "form-control" />
						</div>
						<div class = "form-group">
							<label>تاريخ الميلاد</label>
							<input type = "date" id = "dob" type = "text" value= "<?php echo $acc_fetch['dob']?>" class = "form-control" />
						</div>
						<div class = "form-group">
						<label>مكان الميلاد</label>
						<input type = "text" value= "<?php echo $acc_fetch['pod']?>" id = "pod" class = "form-control"/>
					</div>
					<div class = "form-group">
						<label>العنوان</label>
						<textarea   id = "address" rows="4" cols="50" class = "form-control" /> <?php echo $acc_fetch['address']?></textarea> 
					</div>
					<div class = "form-group">
						<label>الحالة الاجتماعية</label>
						
						 <select value= "<?php echo $acc_fetch['ms']?>"  id = "ms" class = "form-control" >
  <option value="ذكر">ذكر</option>
  <option value="انثى">انثى</option>
  
</select> 
					</div>
					<div class = "form-group">
						<label>الهاتف</label>
						<input type = "number" value= "<?php echo $acc_fetch['phone']?>" class = "form-control" id = "phone"/>
					</div>
					<div class = "form-group">
						<label>البريد الالكتروني</label>
						<input type = "email" value= "<?php echo $acc_fetch['email']?>" class = "form-control" id = "email"/>
					</div>
					<div class = "form-group">
						<label>ملاحظات</label>
						<textarea   class = "form-control" id = "Note" rows="4" cols="50"/> <?php echo $acc_fetch['Note']?>" </textarea> 
					</div>
						<div id = "loading">
						</div>
						<br />
						<div class = "form-group">
							<button  type = "button" id = "mem_edit" class = "btn btn-warning form-control"><span class = "glyphicon glyphicon-edit"></span> حفظ التعديل</button>
						</div>
					</form>
				</div>
			</div>	
		</div>
	</div>
	<footer class = "navbar navbar-fixed-bottom navbar-inverse">
		<label class = "pull-right"><?php echo date('Y', strtotime('+8 HOURS'))?> </label>
	</footer>
</body>	
<script src = "js/jquery-3.1.1.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "js/script.js"></script>
<script src = "js/jquery.dataTables.min.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	})
</script>
</html>