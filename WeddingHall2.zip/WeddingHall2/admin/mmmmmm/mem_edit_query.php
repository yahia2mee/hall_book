<?php
	require_once 'conn.php';
	$firstname = $_POST['firstname'];
	$dob = $_POST['dob'];
	$pod = $_POST['pod'];
	$address = $_POST['address'];
	$ms = $_POST['ms'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$Note = $_POST['Note'];
	
	
	
	$conn->query("UPDATE `member` SET `firstname` = '$firstname', `dob` = '$dob', `pod` = '$pod', `address` = '$address', `ms` = '$ms', `phone` = '$phone', `email` = '$email', `Note` = '$Note' WHERE `mem_id` = '$_REQUEST[mem_id]'") or die(mysqli_error());