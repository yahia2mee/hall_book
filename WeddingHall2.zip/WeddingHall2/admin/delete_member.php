<?php 
	require_once 'conn.php';
	$conn->query("DELETE FROM `reservations` WHERE `rsrv_id` = '$_REQUEST[rsrv_id]'") or die(mysqli_error());
	header("location: member.php");