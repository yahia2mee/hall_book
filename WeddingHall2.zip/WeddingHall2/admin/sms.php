<!DOCTYPE HTML>
<?php
	require_once 'session.php';
	require_once 'account_name.php';
?>
<html lang = "eng">
	<head>
		<meta charset =  "UTF-8">
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1" />
		<title>صالات الافراح</title>
	</head>
<body class = "alert-warning">
	<nav class  = "navbar navbar-inverse">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">صالات الافراح</a>
			</div>
				<ul class="nav navbar-nav navbar-right">
					<li><a><span class = "glyphicon glyphicon-user"></span> <?php echo $acc_name?></a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">اعداد <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="logout.php">خروج</a></li>
						</ul>
					</li>
				</ul>
		</div>
	</nav>
	<div class = "container-fluid" dir="rtl">
		<ul class="nav nav-pills">
			<li><a href="home.php">الرئيسية</a></li>
			<li><a href="account.php">الحساب</a></li>
			<li><a href="member.php">الحجوزات</a></li>
			<li class="active"><a href="sms.php">الرسائل</a></li>
		</ul>
		<br />
		<div class = "col-md-12 well">
			<br/>
			<br/>
			<div class = "alert alert-info">
				<table id = "table" class = "table-bordered" dir="rtl">
					<thead>
						<tr>
						<th>م </th>
							<th>تاريخ الرسالة</th>
							<th>اسم المرسل</th>
														<th>محتوى الرسالة</th>

																					<th>البريد الالكتروني</th>
																												<th>اجراء</th>


						</tr>
					</thead>
					<tbody>
						<?php
							$query = $conn->query("SELECT * FROM `inbox`") or die(mysqli_error());
							while($f_query = $query->fetch_array()){
						?>
						<tr>
							<td><?php echo $f_query['msg_id']?></td>
							<td><?php echo $f_query['msg_date']?></td>
							<td><?php echo $f_query['msg_from']?></td>
							<td><?php echo $f_query['msg_body']?></td>
							<td><?php echo $f_query['msg_email']?></td>
							<td><center> <a  href = "delete_sms.php?msg_id=<?php echo $f_query['msg_id']?>" class = "btn btn-danger"><span class = "glyphicon glyphicon-trash"></span> حذف</a></center></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">اضافة نشاط</h4>
			</div>
			<div class="modal-body">
				<form method = "POST" enctype = "multipart/form-data" dir="rtl">
					<div class = "form-group">
						<label>اسم النشاط</label>
						<input type = "text" class = "form-control" id = "club"/>
					</div>
					<div id = "loading">
						
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" id= "save_club" class="btn btn-primary"><span class = "glyphicon glyphicon-save"></span> حفظ</button>
			</div>
				</form>
		</div>
	</div>
	</div>
	<footer class = "navbar navbar-fixed-bottom navbar-inverse">
		<label class = "pull-right">2018 <?php echo date('Y', strtotime('+8 HOURS'))?> <a href = "#"></a></label>
	</footer>
</body>	
<script src = "js/jquery-3.1.1.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "js/script.js"></script>
<script src = "js/jquery.dataTables.min.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	})
</script>
</html>