<?php
	require_once 'conn.php';
	$conn->query("DELETE FROM `inbox` WHERE `msg_id` = $_REQUEST[msg_id]") or die(mysqli_error());
	header("location: sms.php");