<?php
	$conn = new mysqli('localhost', 'root', '', 'hans_db');
	if(!$conn){
		die('Could not Connect to Database' . $conn->mysqli_error );
	}