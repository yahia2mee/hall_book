<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:ice="http://ns.adobe.com/incontextediting">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>Hans Guest House</title>
<!-- TemplateEndEditable -->
<link href="../stylesheet.css" rel="stylesheet" type="text/css" />
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
<script src="../includes/ice/ice.js" type="text/javascript"></script>
</head>
<body>
<!-- TemplateBeginEditable name="body" -->
	<div class="container" >
        <a href="#"><img src="../images/logo.png" align="left" /></a>
            <div id="headr_img" ice:editable="*">
                <span id="main_nav"> 
                	   	<a href="#">Home</a> |  
						<a href="#">Accomodations</a> |  
                        <a href="../$">Reservations</a> |  
                        <a href="contact.php">Contact Us</a>
                </span>
            </div>
   <div id="content_container">
   	 <p></p>
      </div>
         <div id="footer_container">
         	Copyright © 2014 Hans Guest House
         </div>
</div>
<!-- TemplateEndEditable -->
</body>
</html>