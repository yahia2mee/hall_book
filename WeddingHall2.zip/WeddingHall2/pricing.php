<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>صالات الافراح</title>
    <link href="stylesheet.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/grid.css" type="text/css" media="screen" />   
    <script src="js/jquery-1.6.2.min.js" type="text/javascript"></script>    
	<!--[if lt IE 7]>
        <div style=' clear: both; text-align:center; position: relative;'>
            <a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0"  alt="" /></a>
        </div>
	<![endif]-->
    <!--[if lt IE 9]>
   		<script type="text/javascript" src="js/html5.js"></script>
        <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
	<![endif]-->
</head>
<body>
    <div class="main_container" >
        <a href="index.php"><img src="images/logo.png" align="left" /></a>
            <div id="headr_img">
                <span id="main_nav"> <b>
                	   	<a href="index.php">الرئيسية</a> |  
						<a href="catalogue.php">العرض</a> |  
                        <a href="reserve.php">الحجز</a> |  
                        <a href="contact.php">اتصل بنا</a> </b>
	            </span>
            </div>
    
<!-- content -->
    <section id="content">
        <div class="bg-top">
        	<div class="bg-top-2">
                <div class="bg">
                    <div class="bg-top-shadow" DIR="RTL">
                        <div class="main">
                        <h2 id="home_header">أسعار الصالات</h2><br/>
                            <div class="box">
                                <div class="padding">
                                    <div class="container_12" DIR="RTL">
                                        <div class="wrapper">
                                            <div class="grid_12">
                                            	<div class="indent-left p2">
                                                </div>
                                                <div class="wrapper p4" >
														
                                                    <article class="grid_4 alpha">
                                                       <div class="indent-left">
                                                         <figure class="frame2 p2"><img src="images2/stan1.jpg" alt="" /></figure>
                                                           <p ><H4>صالة فيوتشر</H4></p>
صالة فخمة جداً تتسع لعدد 1500 شخص                                                            <div class="wrapper">
<br /><br />
                                                            	<span class="price fleft">40 SDN</span>
                                                                <a class="button fright" href="standard.php">عرض الصور</a>
                                                            </div>
                                                        </div>
                                                    </article>
                                                    <article class="grid_4">
                                                        <div class="indent3">
                                                            <figure class="frame2 p2"><img src="images2/del1.jpg" alt="" /></figure>
                                                             <p ><H4>صالة ماجستك</H4></p>
صالة فخمة تتسع لعدد 1200 شخص                                                            <div class="wrapper">
<p>السعر يشمل الفيديو </p>
                                                            	<span class="price fleft">35 SDN</span>
                                                                <a class="button fright" href="deluxe.php">عرض الصور</a>
                                                            </div>
                                                        </div>
                                                    </article>
                                                    <article class="grid_4 omega">
                                                        <div class="indent-right">
                                                            <figure class="frame2 p2"><img src="images2/fam1.jpg" alt="" /></figure>
                                                             <p ><H4>صالة الوداد</H4></p>
صالة فخمة تتسع لعدد 1200 شخص
<p>السعر يشمل الفيديو</p>                                                            <div class="wrapper">
                                                            	<span class="price fleft">35 SDN</span>
                                                                <a class="button fright" href="family.php">عرض الصور</a>
                                                            </div>
                                                        </div>
                                                    </article>
											
                                                </div> 
   <article class="grid_8 alpha">
                        	                           <h4 class=""></h4>
                                                            <div class="wrapper" >
                            	                               <article class="prev-indent-bot2">
                                	                               <div class="indent-right2" ALIGN="RIGHT">
                                                                        <ul class="price-list" >
                                                                            <li><span></span><strong>&nbsp;</strong></li>
                                                                            <li><span></span><strong>&nbsp;</strong></li>
                                                                            <li><span></span><strong>&nbsp;</strong></li>
                                                                            <li class="last"><span></span><strong>&nbsp;</strong></li>
                                                                        </ul>
                                                                    </div>
                                                                </article>
                                                         <article class="grid_4 omega" >
                                	                           <div class="indent-right2">
                                                                    <ul class="price-list">
																	<li><span><H4>الإضافات</H4></span><a href="#"></a><strong>&nbsp;</strong></li>
                                                                        <li><span>ساعة اضافية</span><a href="#"> 3,000 جنيه سوداني </a><strong>&nbsp;</strong></li>
                                                                        <li><span>الفنان</span><a href="#">30,000 - 45,000 جنيه سوداني</a><strong>&nbsp;</strong></li>
                                                                        <li><span>العشاء</span><a href="#">40,000 جنيه سوداني</a><strong>&nbsp;</strong></li>
                                                                        <li><span>التصوير</span><a href="#">10,000 جنيه سوداني</a><strong>&nbsp;</strong></li>
                                                                    </ul>
                                                                </div>
                                                            </article>
                                                        </div>
                                                </article>
												
                    	                          <article class="grid_4 omega" >
                                                        <div class="indent-right">
                                                            <figure class="frame2 p2"><img src="images2/fam11.jpg" alt="" /></figure>
                                                            <p ><H4> صالة القصر الملكي</H4></p>
صالة فخمة تتسع لعدد 1500 شخص                                                            <div class="wrapper">
<p> العشاء غير إجباري</p>
                                                            	<span class="price fleft">37 SDN</span>
                                                                <a class="button fright" href="family.php">عرض الصور</a>
                                                            </div>
                                                        </div>
                                                    </article>
													
                                                 
                                             </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>	
            </div>
       </div>
    </section>
   <div id="footer_container">
         	2018
    </div>
</div>
</body>
</html>

